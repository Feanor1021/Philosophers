/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   control_init_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fyardimc <fyardimc@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/16 13:19:59 by fyardimc          #+#    #+#             */
/*   Updated: 2022/10/16 15:47:52 by fyardimc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers_bonus.h"

int	init_sem(t_arg *rules)
{
	sem_unlink("/sem_forks");
	sem_unlink("/sem_write");
	sem_unlink("/sem_mealcheck");
	rules->forks = sem_open("/sem_forks", O_CREAT, S_IRWXU, rules->philo_num);
	rules->writing = sem_open("/sem_write", O_CREAT, S_IRWXU, 1);
	rules->die_check = sem_open("/sem_mealcheck", O_CREAT, S_IRWXU, 1);
	if (rules->forks == SEM_FAILED || rules->writing == SEM_FAILED
		|| rules->die_check == SEM_FAILED)
		return (error_message("semaphore can not opened!!!"));
	return (0);
}

int	teach_ph(t_arg *rules)
{
	int	i;

	i = 0;
	while (i < rules->philo_num)
	{
		rules->philo[i].id = i;
		rules->philo[i].last_eat = 0;
		rules->philo[i].meal_count = 0;
		rules->philo[i].rules = rules;
		i++;
	}
	return (0);
}

int	check_args(t_arg *rules, int argc)
{
	if (argc == 5)
	{
		if ((rules->philo_num < 1) || (rules->die_time < 0)
			|| (rules->eat_time < 0) || (rules->sleep_time < 0))
			return (1);
	}
	if (argc == 6)
		if (rules->must_eat < 0)
			return (1);
	return (0);
}

int	set_rules(t_arg *rules, char **argv, int argc)
{
	rules->philo_num = ft_atoi(argv[1]);
	rules->die_time = ft_atoi(argv[2]);
	rules->eat_time = ft_atoi(argv[3]);
	rules->sleep_time = ft_atoi(argv[4]);
	rules->died = 1;
	rules->all_ate = 1;
	rules->philo = malloc(sizeof(t_philo) * rules->philo_num);
	if (argc == 6)
		rules->must_eat = ft_atoi(argv[5]);
	else
		rules->must_eat = -1;
	if (check_args(rules, argc))
		return (error_message("Wrong argument format!!!"));
	if (init_sem(rules))
		return (error_message("Can't initilize mutexes!!!"));
	if (teach_ph(rules))
		return (error_message("philo don't\
        want to eat spagetti :( they chose to die..."));
	return (0);
}
