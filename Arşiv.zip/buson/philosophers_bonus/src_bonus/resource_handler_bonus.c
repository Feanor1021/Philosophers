/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   resource_handler_bonus.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fyardimc <fyardimc@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/16 13:41:13 by fyardimc          #+#    #+#             */
/*   Updated: 2022/10/16 18:17:38 by fyardimc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers_bonus.h"

int	eat_spagetti(t_philo *ph)
{
	sem_wait(ph->rules->forks);
	action_philo("\e[0;34mhas taken a fork🍴🤤\n\033[0m", ph->rules, ph->id);
	if (ph->rules->philo_num == 1)
		return (1);
	sem_wait(ph->rules->forks);
	action_philo("\e[0;34mhas taken a fork🤤🍴\n\033[0m", ph->rules, ph->id);
	sam_wait(ph->rules->die_check);
	action_philo("\033[0;32mis eating 🍝\n\033[0m", ph->rules, ph->id);
	ph->last_eat = timestamp();
	sem_post(ph->rules->die_check);
	wait_sleep(ph->rules->eat_time, ph->rules);
	ph->meal_count++;
	sem_post(ph->rules->forks);
	sem_post(ph->rules->forks);
	return (0);
}

void	resources(void *philo)
{
	t_philo	*ph;

	ph = (t_philo *)philo;
	ph->last_eat = timestamp();
	pthread_create(&(ph->died), NULL, dead_checker, philo);
	if (ph->id % 2 == 1)
		usleep(15000);
	while (ph->rules->died)
	{
		if (ph->rules->all_ate == 0 || ph->rules->died == 0)
			break ;
		if (eat_spagetti(ph))
			return (NULL);
		action_philo("\033[0;33mis sleeping 😴\n\033[0m", ph->rules, ph->id);
		wait_sleep(ph->rules->sleep_time, ph->rules);
		action_philo("\033[0;33mis tkinking 🤔\n\033[0m", ph->rules, ph->id);
	}
	return (NULL);
}

void	destroy_all(t_arg *rules)
{
	int	i;

	i = 0;
	while (rules->philo_num > i)
	{
		pthread_join((rules->philo + i)->philos, NULL);
		i++;
	}
	i = 0;
	while (rules->philo_num > i)
	{
		pthread_mutex_destroy(&rules->forks[i]);
		i++;
	}
	pthread_mutex_destroy(&rules->writing);
	pthread_mutex_destroy(&rules->die_check);
}

void	dead_checker(t_arg *r)
{
	while (r->all_ate)
	{

		pthread_mutex_lock(&(r->die_check));
		if (time_diff((r->philo[r->i].last_eat),
				timestamp()) > r->die_time)
		{
				action_philo("\033[0;31mdied💀\033[0m\n", r, r->philo->id);
			r->died = 0;
		}
		pthread_mutex_unlock(&(r->die_check));
		usleep(100);
		if (r->died == 0)
			break ;
		r->i = 0;
		while (r->i < r->philo_num && r->must_eat != -1
			&& r->philo[r->i].meal_count >= r->must_eat)
			r->i++;
		if (r->i == r->philo_num)
			r->all_ate = 0;
	}
}

int	handle_resources(t_arg *rules)
{
	int	i;

	i = 0;
	rules->first_time = timestamp();
	while (i < rules->philo_num)
	{
		rules->philo->pid=fork();
		if(rules->philo[i].pid < 0)
			return (1);
		if(rules->philo[i].pid == 0)
			resources((void *)&(rules->philo[i]));
		usleep(100);
	}
	destroy_all(rules);
	return (0);
}
